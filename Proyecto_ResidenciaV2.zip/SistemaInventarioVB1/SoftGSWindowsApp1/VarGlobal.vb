﻿Module VarGlobal
    Public varnickusuario As String
    Public varcodigousuario As String
    Public varpermiso As String
End Module
