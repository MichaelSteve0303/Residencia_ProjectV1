﻿Imports System.Data.SqlClient
Imports System.Diagnostics
Imports System.IO

Public Class BuscarTicketForm
    Inherits System.Windows.Forms.Form

    Private WithEvents lblIDTicket As System.Windows.Forms.Label
    Private WithEvents txtIDTicket As System.Windows.Forms.TextBox
    Private WithEvents btnBuscar As System.Windows.Forms.Button
    Private WithEvents dgvHistorial As System.Windows.Forms.DataGridView
    Private _nombreUsuario As String

    ' Declarar la conexión y el comando para SQL Server
    Private conn As SqlConnection
    Private cmd As SqlCommand

    ' Constructor que recibe el nombre de usuario como argumento
    Public Sub New(nombreUsuario As String)
        ' Configurar los controles manualmente en el constructor del formulario
        ConfigurarControles()
        _nombreUsuario = nombreUsuario ' Almacenar el nombre de usuario

        ' Establecer la conexión con la base de datos SQL Server
        Dim connectionString As String = "Data Source=localhost\SQLEXPRESS;Initial Catalog=VaiInventario123;Integrated Security=True;"
        conn = New SqlConnection(connectionString)
        cmd = conn.CreateCommand()

        ' Cargar el historial al iniciar la aplicación
        CargarHistorial()
    End Sub

    ' Método para cargar el historial al iniciar la aplicación
    Private Sub CargarHistorial()
        dgvHistorial.Rows.Clear()
        conn.Open()
        cmd.CommandText = "SELECT * FROM HistorialTickets"
        Dim reader As SqlDataReader = cmd.ExecuteReader()
        While reader.Read()
            dgvHistorial.Rows.Add(reader("TicketID"), reader("FechaHora"), reader("Usuario"))
        End While
        reader.Close()
        conn.Close()
    End Sub

    Private Sub ConfigurarControles()
        ' Configurar el formulario
        Me.FormBorderStyle = FormBorderStyle.None
        Me.WindowState = FormWindowState.Maximized
        Me.Text = "Buscar Ticket"

        ' Configuración del Label lblIDTicket
        Me.lblIDTicket = New System.Windows.Forms.Label()
        Me.lblIDTicket.AutoSize = True
        Me.lblIDTicket.Text = "ID de Ticket:"
        Me.lblIDTicket.Location = New Point(50, 50) ' Colocar en la posición deseada
        Me.Controls.Add(Me.lblIDTicket)

        ' Configuración del TextBox txtIDTicket
        Me.txtIDTicket = New System.Windows.Forms.TextBox()
        Me.txtIDTicket.Size = New System.Drawing.Size(150, 20) ' Ajustar el tamaño del textbox según tus necesidades
        Me.txtIDTicket.Location = New Point(Me.lblIDTicket.Right + 40, 50) ' Colocar al lado derecho del label con un pequeño espacio
        Me.Controls.Add(Me.txtIDTicket)

        ' Configuración del Button btnBuscar
        Me.btnBuscar = New System.Windows.Forms.Button()
        Me.btnBuscar.Text = "Buscar"
        Me.btnBuscar.Location = New Point(Me.txtIDTicket.Right + 10, 50) ' Colocar al lado derecho del textbox con un pequeño espacio
        Me.Controls.Add(Me.btnBuscar)

        ' Configuración del DataGridView dgvHistorial
        Me.dgvHistorial = New System.Windows.Forms.DataGridView()
        Me.dgvHistorial.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right Or AnchorStyles.Bottom
        Me.dgvHistorial.Location = New Point(50, Me.btnBuscar.Bottom + 20) ' Colocar debajo del botón con un pequeño espacio
        Me.dgvHistorial.Size = New Size(Me.ClientSize.Width - 100, Me.ClientSize.Height - Me.btnBuscar.Bottom - 100) ' Tamaño del DataGridView ajustado al espacio restante
        Me.Controls.Add(Me.dgvHistorial)

        ' Configurar las columnas del DataGridView
        Me.dgvHistorial.Columns.Add("IDTicket", "ID de Ticket")
        Me.dgvHistorial.Columns.Add("FechaHora", "Fecha y Hora")
        Me.dgvHistorial.Columns.Add("Usuario", "Usuario") ' Nueva columna para el nombre de usuario
        Me.dgvHistorial.Columns("IDTicket").AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill ' Ancho fijo para la columna IDTicket
        Me.dgvHistorial.Columns("FechaHora").AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill ' Ancho fijo para la columna FechaHora
        Me.dgvHistorial.Columns("Usuario").AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill


        ' Agregar el evento Click del botón btnBuscar
        AddHandler Me.btnBuscar.Click, AddressOf btnBuscar_Click
    End Sub

    Private Function BuscarTicketPorId(ticketId As String) As String
        ' Construir la ruta del archivo PDF usando el ID del ticket
        Dim rutaCarpetaPDF As String = "C:\Users\micha\OneDrive\Documentos\SistemaInventarioVB1\SoftGSWindowsApp1\bin\Debug\"
        Dim rutaPDF As String = Path.Combine(rutaCarpetaPDF, "ticket_" & ticketId & ".pdf")

        ' Verificar si el archivo PDF existe
        If File.Exists(rutaPDF) Then
            Return rutaPDF
        Else
            Return String.Empty
        End If
    End Function



    Private Sub btnBuscar_Click(sender As Object, e As EventArgs)
        Dim ticketId As String = txtIDTicket.Text.Trim()

        ' Validar si se ingresó un ID de ticket
        If String.IsNullOrEmpty(ticketId) Then
            MessageBox.Show("Por favor, ingrese un ID de ticket.")
            Return
        End If

        ' Buscar el ticket en la base de datos
        Dim rutaPDF As String = BuscarTicketPorId(ticketId)

        ' Verificar si se encontró el ticket
        If Not String.IsNullOrEmpty(rutaPDF) Then
            ' Mostrar el archivo PDF correspondiente al ticket
            MostrarArchivoPDF(rutaPDF)
            ' Agregar el ID del ticket, la fecha y hora actual, y el nombre de usuario al historial
            AgregarEntradaHistorial(ticketId, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), _nombreUsuario)
        Else
            MessageBox.Show("No se encontró el ticket con el ID especificado.")
        End If
    End Sub


    ' Método para agregar una entrada al historial
    ' Método para agregar una entrada al historial
    Private Sub AgregarEntradaHistorial(ticketId As String, fechaHora As String, usuario As String)
        conn.Open()
        cmd.CommandText = "INSERT INTO HistorialTickets (TicketID, FechaHora, Usuario) VALUES (@TicketID, @FechaHora, @Usuario)"

        ' Limpiar los parámetros antes de agregar nuevos parámetros
        cmd.Parameters.Clear()

        cmd.Parameters.AddWithValue("@TicketID", ticketId)
        cmd.Parameters.AddWithValue("@FechaHora", fechaHora)
        cmd.Parameters.AddWithValue("@Usuario", usuario)
        cmd.ExecuteNonQuery()
        conn.Close()
    End Sub


    Private Sub MostrarArchivoPDF(rutaPDF As String)
        If Not String.IsNullOrEmpty(rutaPDF) AndAlso File.Exists(rutaPDF) Then
            Try
                Process.Start(rutaPDF)
            Catch ex As Exception
                MessageBox.Show("No se pudo abrir el archivo PDF del ticket: " & ex.Message, "Error al Abrir PDF", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        Else
            MessageBox.Show("No se encontró el archivo PDF del ticket.", "Archivo no Encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

End Class

Public Class Ticket
    Public Property RutaPDF As String
End Class
