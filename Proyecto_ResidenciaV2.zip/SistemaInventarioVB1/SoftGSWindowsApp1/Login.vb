﻿Imports ClassLibrary1

Public Class Login
    Dim obj As New Class1
    Dim principalForm As New Principal()

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Cargar la imagen desde los recursos del proyecto
        PictureBox1.Image = My.Resources.gafi
        ' Reemplaza "NombreDeTuImagen" con el nombre de tu imagen en los recursos
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom ' Ajustar el modo de visualización de la imagen
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Convert.ToChar(Keys.Enter) Then
            TextBox2.Focus() ' Cambiar el foco al campo de texto de contraseña
        End If
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If e.KeyChar = Convert.ToChar(Keys.Enter) Then
            btnlogin.PerformClick() ' Simular un clic en el botón de inicio de sesión
        End If
    End Sub

    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        Dim dt = obj.Login(TextBox1.Text, TextBox2.Text)

        If (dt.Rows.Count > 0) Then
            MsgBox("Bienvenido " + dt.Rows(0)(0).ToString, MsgBoxStyle.Exclamation, "Mensaje ")
            varnickusuario = dt.Rows(0)(0).ToString
            varcodigousuario = dt.Rows(0)(4).ToString
            varpermiso = dt.Rows(0)(3).ToString
            SesionUsuario.IniciarSesion(dt.Rows(0)(0).ToString) ' Guarda el nombre de usuario en la sesión
            principalForm.ShowDialog()
            TextBox1.Text = ""
            TextBox2.Text = ""
        Else
            MsgBox("Usuario o Contraseña Incorrecta", MsgBoxStyle.Critical, "Alerta")
            TextBox1.Text = ""
            TextBox2.Text = ""
        End If
    End Sub
End Class
