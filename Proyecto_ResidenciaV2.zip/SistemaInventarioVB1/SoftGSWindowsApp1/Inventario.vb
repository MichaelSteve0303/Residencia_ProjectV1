﻿Imports System.Drawing.Printing
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports System.IO
Imports System.Data.SqlClient
Imports ClassLibrary1

Public Class Inventario

    Dim obj As New Class1
    Dim nombreUsuarioSesion As String


    Private Sub Inventario_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Cargamos la imagen de GAFI que está debajo de los botones.
        PictureBox1.Image = My.Resources.gafi
        ' Reemplaza "NombreDeTuImagen" con el nombre de tu imagen en los recursos
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom ' Ajustar el modo de visualización de la imagen

        ComboBox1.DataSource = obj.ListarCategoria()
        ComboBox1.ValueMember = "IdCategoria"
        ComboBox1.DisplayMember = "Nombre"

        ComboBox2.DataSource = obj.ListarCategoria()
        ComboBox2.ValueMember = "IdCategoria"
        ComboBox2.DisplayMember = "Nombre"

        listarproductos()
    End Sub

    Private Sub listarproductos()
        Dim dtpro = obj.BuscarProductos("", "")
        DataGridView1.DataSource = dtpro
    End Sub

    Private Sub ComboBox2_SelectedValueChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedValueChanged
        Dim dtpro = obj.BuscarProductos(TextBox8.Text, ComboBox2.SelectedValue.ToString)
        DataGridView1.DataSource = dtpro
    End Sub

    Private Sub limpiar()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        ComboBox1.SelectedIndex = 0
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim dtpro = obj.BuscarProductos(TextBox8.Text, ComboBox2.SelectedValue.ToString)
        DataGridView1.DataSource = dtpro
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ComboBox1.SelectedIndex > 0 Then
            obj.RegistrarProducto(TextBox2.Text, ComboBox1.SelectedValue.ToString, TextBox4.Text, TextBox5.Text)
            listarproductos()
            limpiar()
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        limpiar()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        obj.EliminarProducto(TextBox1.Text)
        listarproductos()
        limpiar()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        TextBox1.Text = DataGridView1.Item(0, e.RowIndex).Value
        TextBox2.Text = DataGridView1.Item(1, e.RowIndex).Value
        ComboBox1.SelectedValue = DataGridView1.Item(2, e.RowIndex).Value
        TextBox4.Text = DataGridView1.Item(4, e.RowIndex).Value
        TextBox5.Text = DataGridView1.Item(5, e.RowIndex).Value
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        obj.ModificarProducto(TextBox1.Text, TextBox2.Text, ComboBox1.SelectedValue, TextBox4.Text, TextBox5.Text)
        listarproductos()
        limpiar()
    End Sub

    Private Sub BTPRINT_Click(sender As Object, e As EventArgs) Handles BTPRINT.Click
        Dim ticketId As String = GenerarTicketId()
        Dim usuarioObtuvoTicket As String = ObtenerNombreUsuarioDeSesion() ' Obtener el nombre de usuario actual
        GenerarPDF(ticketId, usuarioObtuvoTicket) ' Llamar al método con dos argumentos
    End Sub

    Private Function GenerarTicketId() As String
        ' Generar un ID único para el ticket
        Return Guid.NewGuid().ToString().Substring(0, 10) ' Obtener los primeros 10 caracteres del GUID generado
    End Function

    Private Sub GenerarPDF(ByVal ticketId As String, ByVal usuarioObtuvoTicket As String)
        ' Generar el PDF del ticket y guardarlo en la base de datos con su ID único
        Dim doc As New Document()

        Try
            Dim filePath As String = "ticket_" & ticketId & ".pdf" ' Cambia el nombre del archivo para incluir el ID único
            Dim writer As PdfWriter = PdfWriter.GetInstance(doc, New FileStream(filePath, FileMode.Create))
            doc.Open()

            ' Agregar logo de la empresa (centrado)
            Dim logoEmpresa As Image = Image.GetInstance("C:\Users\micha\OneDrive\Documentos\SistemaInventarioVB1\SoftGSWindowsApp1\Resources\gafi.png")
            logoEmpresa.ScaleToFit(100, 100)
            logoEmpresa.Alignment = Element.ALIGN_CENTER
            doc.Add(logoEmpresa)

            ' Información del ticket (centrado)
            Dim titulo As New Paragraph("TICKET DE INVENTARIO", FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 18))
            titulo.Alignment = Element.ALIGN_CENTER
            doc.Add(titulo)

            ' Agregar número de ticket
            Dim numeroTicket As New Paragraph("Numero de Ticket: " & ticketId, FontFactory.GetFont(FontFactory.HELVETICA, 12))
            numeroTicket.Alignment = Element.ALIGN_CENTER
            doc.Add(numeroTicket)

            Dim fecha As New Paragraph("Fecha: " & DateTime.Now.ToString("dd/MM/yyyy"), FontFactory.GetFont(FontFactory.HELVETICA, 12))
            fecha.Alignment = Element.ALIGN_CENTER
            doc.Add(fecha)

            Dim horaImpresion As New Paragraph("Hora de impresión: " & DateTime.Now.ToString("HH:mm:ss"), FontFactory.GetFont(FontFactory.HELVETICA, 12))
            horaImpresion.Alignment = Element.ALIGN_CENTER
            doc.Add(horaImpresion)

            ' Obtener el nombre de usuario de la sesión
            Dim nombreUsuario As String = ObtenerNombreUsuarioDeSesion()
            Dim usuario As New Paragraph("Usuario: " & nombreUsuario, FontFactory.GetFont(FontFactory.HELVETICA, 12))
            usuario.Alignment = Element.ALIGN_CENTER
            doc.Add(usuario)

            Dim movimiento As New Paragraph("Movimiento: Inventario", FontFactory.GetFont(FontFactory.HELVETICA, 12))
            movimiento.Alignment = Element.ALIGN_CENTER
            doc.Add(movimiento)

            ' Suma de todo el inventario
            Dim suma As Decimal = 0
            For Each row As DataGridViewRow In DataGridView1.Rows
                Dim precio As Decimal = Convert.ToDecimal(row.Cells("Precio").Value)
                Dim stock As Integer = Convert.ToInt32(row.Cells("Stock").Value)
                suma += precio * stock
            Next

            Dim total As New Paragraph("Total del inventario: $" & suma.ToString("0.00"), FontFactory.GetFont(FontFactory.HELVETICA, 12))
            total.Alignment = Element.ALIGN_CENTER
            doc.Add(total)

            doc.Add(New Paragraph(" ")) ' Espacio en blanco

            ' Detalles del inventario (centrado)
            Dim table As New PdfPTable(DataGridView1.Columns.Count)
            For Each column As DataGridViewColumn In DataGridView1.Columns
                table.AddCell(New PdfPCell(New Phrase(column.HeaderText, FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 10))))
            Next

            For Each row As DataGridViewRow In DataGridView1.Rows
                For Each cell As DataGridViewCell In row.Cells
                    table.AddCell(New PdfPCell(New Phrase(cell.Value.ToString(), FontFactory.GetFont(FontFactory.HELVETICA, 10))))
                Next
            Next
            table.WidthPercentage = 100
            table.HorizontalAlignment = Element.ALIGN_CENTER
            doc.Add(table)

            ' Frase corporativa (centrado)
            Dim fraseCorporativa As New Paragraph("CORPORATIVO GAFI SERVICIOS S.A. de C.V", FontFactory.GetFont(FontFactory.HELVETICA, 12))
            fraseCorporativa.Alignment = Element.ALIGN_CENTER
            doc.Add(fraseCorporativa)

            ' Guardar el ticket en la base de datos con su ID único
            GuardarTicketEnBaseDeDatos(ticketId)

            ' Guardar el nombre de usuario que obtuvo el ticket en la base de datos
            GuardarUsuarioObtuvoTicketEnBaseDeDatos(ticketId, usuarioObtuvoTicket)

            ' Cerrar el documento PDF
            doc.Close()

            ' Abrir el PDF generado
            AbrirPDF(filePath)
        Catch ex As Exception
            MessageBox.Show("Error al generar el PDF: " & ex.Message)
        End Try
    End Sub

    Private Sub GuardarUsuarioObtuvoTicketEnBaseDeDatos(ByVal ticketId As String, ByVal usuarioObtuvoTicket As String)
        ' Conexión a la base de datos
        Dim connectionString As String = "Data Source=localhost\SQLEXPRESS;Initial Catalog=VaiInventario123;Integrated Security=True"
        Dim connection As New SqlConnection(connectionString)

        Try
            ' Abrir la conexión
            connection.Open()

            ' Comando SQL para actualizar el nombre de usuario que obtuvo el ticket
            Dim query As String = "UPDATE Tickets SET UsuarioObtuvoTicket = @UsuarioObtuvoTicket WHERE TicketId = @TicketId"
            Dim command As New SqlCommand(query, connection)

            ' Asignar los valores de los parámetros del comando SQL
            command.Parameters.AddWithValue("@TicketId", ticketId)
            command.Parameters.AddWithValue("@UsuarioObtuvoTicket", usuarioObtuvoTicket)

            ' Ejecutar el comando SQL
            command.ExecuteNonQuery()

            MessageBox.Show("Nombre de usuario que obtuvo el ticket guardado en la base de datos.")
        Catch ex As Exception
            MessageBox.Show("Error al guardar el nombre de usuario que obtuvo el ticket en la base de datos: " & ex.Message)
        Finally
            ' Cerrar la conexión
            connection.Close()
        End Try
    End Sub




    Private Function ObtenerNombreUsuarioDeSesion() As String
        ' Aquí debes implementar la lógica para obtener el nombre de usuario de la sesión
        ' Puedes recuperarlo de una variable global, una clase de sesión o cualquier otra fuente confiable
        ' En este ejemplo, se asume que hay un método llamado ObtenerNombreUsuario() en la clase SesionUsuario
        Return SesionUsuario.ObtenerNombreUsuario()
    End Function



    Private Sub AbrirPDF(ByVal filePath As String)
        Try
            System.Diagnostics.Process.Start(filePath)
        Catch ex As Exception
            MessageBox.Show("Error al abrir el archivo PDF: " & ex.Message)
        End Try
    End Sub

    Private Sub BTREFRESH_Click(sender As Object, e As EventArgs) Handles BTREFRESH.Click
        DataGridView1.Rows.Clear()
    End Sub

    Private Sub GuardarTicketEnBaseDeDatos(ByVal ticketId As String)
        ' Conexión a la base de datos
        Dim connectionString As String = "Data Source=localhost\SQLEXPRESS;Initial Catalog=VaiInventario123;Integrated Security=True"
        Dim connection As New SqlConnection(connectionString)

        Try
            ' Abrir la conexión
            connection.Open()

            ' Comando SQL para insertar el ticket en la base de datos
            Dim query As String = "INSERT INTO Tickets (TicketId) VALUES (@TicketId)"
            Dim command As New SqlCommand(query, connection)

            ' Asignar el valor del ID del ticket al parámetro del comando SQL
            command.Parameters.AddWithValue("@TicketId", ticketId)

            ' Ejecutar el comando SQL
            command.ExecuteNonQuery()

            MessageBox.Show("Ticket guardado en la base de datos con ID: " & ticketId)
        Catch ex As Exception
            MessageBox.Show("Error al guardar el ticket en la base de datos: " & ex.Message)
        Finally
            ' Cerrar la conexión
            connection.Close()
        End Try
    End Sub

End Class
