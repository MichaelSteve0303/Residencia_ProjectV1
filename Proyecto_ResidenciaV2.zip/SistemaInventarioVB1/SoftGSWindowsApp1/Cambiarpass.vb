﻿Imports ClassLibrary1
Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Cambiarpass
    Dim obj As New Class1

    Private Sub Cambiarpass_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Cargar los usuarios desde la base de datos al ComboBox
        Try
            CargarUsuarios()
        Catch ex As Exception
            MessageBox.Show("Error al cargar usuarios: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub CargarUsuarios()
        Try
            ' Limpiar ComboBox antes de cargar los usuarios
            ComboBox1.Items.Clear()

            ' Obtener usuarios desde la base de datos
            Dim dtUsuarios As DataTable = obj.ObtenerUsuarios()

            ' Verificar si se encontraron usuarios
            If dtUsuarios IsNot Nothing AndAlso dtUsuarios.Rows.Count > 0 Then
                ' Iterar a través de los usuarios y agregarlos al ComboBox
                For Each row As DataRow In dtUsuarios.Rows
                    ComboBox1.Items.Add(New KeyValuePair(Of String, String)(row("Codigo").ToString(), row("Nombre").ToString()))
                Next
            Else
                MessageBox.Show("No se encontraron usuarios en la base de datos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            MessageBox.Show("Error al cargar usuarios: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btncambiar_Click(sender As Object, e As EventArgs) Handles btncambiar.Click
        If txtnueva.TextLength > 2 AndAlso ComboBox1.SelectedItem IsNot Nothing Then
            ' Obtener el código del usuario seleccionado en el ComboBox
            Dim codigoUsuario As String = DirectCast(ComboBox1.SelectedItem, KeyValuePair(Of String, String)).Key

            ' Cambiar la contraseña del usuario seleccionado
            obj.CambiarPass(codigoUsuario, txtnueva.Text)
            MessageBox.Show("Contraseña cambiada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtnueva.Text = ""
        Else
            MessageBox.Show("Seleccione un usuario y asegúrese de que la nueva contraseña tenga al menos 3 caracteres.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txtnueva.Text = ""
    End Sub
End Class
